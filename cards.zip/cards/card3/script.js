function aretes(){
    let aretes = document.getElementById("aretes").value 
    document.getElementById("info").innerHTML = "25.000k"

}