function zapato(){
    let tenis = document.getElementById("tenis").value 
    document.getElementById("info").innerHTML = "1.000.000k"

}

