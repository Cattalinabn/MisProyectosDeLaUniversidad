function gorra(){
    let gorra = document.getElementById("gorra").value 
    document.getElementById("info").innerHTML = "150.000k"

}
