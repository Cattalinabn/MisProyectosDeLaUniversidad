$(document).ready(function(){
    $('.slider').slick({
      dots: false,
      arrows: true,
      infinite: true,
      speed: 500,
      fade: true,
      cssEase: 'linear'
    });
  });
