function consignar(){
    let Ncuenta = parseInt (document.getElementById('Ncuenta').value);
    let cuenta = document.getElementById('cuenta').value;
    let pago = document.getElementById('pago').value;

    alert("Consigancion exitosa")

    console.log ("Numero de cuenta: "+Ncuenta);
    console.log ("Tipo de cuenta: "+cuenta);
    console.log ("Forma de pago: "+pago);
}