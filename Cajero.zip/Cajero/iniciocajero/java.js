let intentos = 0
function Ingresar(){
let usuario = document.getElementById('usuario').value;
let contraseña = document.getElementById('password').value;


    if (usuario == "catta" , contraseña == "000"){
        window.location="index.html";
    }
    else {
        
        intentos++
        if(intentos === 3){
            document.getElementById("usuario").disabled = true
            document.getElementById("password").disabled = true
            alert ("Cuenta bloqueada por 24 horas")
            setTimeout(function(){
                document.getElementById("usuario").disabled = false
                document.getElementById("password").disabled = false
                intentos = 0
            }, 24 * 60 * 60 * 1000)
          
        }
        else{
            alert ("Usuario o contraseña incorrecta, intentos fallidos: "+ intentos)
        }  
    }
    

}

