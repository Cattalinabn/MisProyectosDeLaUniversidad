function Transferencia(){
    let nombre = document.getElementById('nombre').value;
    let correo = document.getElementById('correo').value;
    let numcuenta = parseInt(document.getElementById('Numcuenta').value);
    let cuenta = document.getElementById('cuenta').value;
    let banco = document.getElementById('banco').value;
    let valor = parseInt(document.getElementById('valor').value)

    alert ('La transferencia fue exitosa');
    console.log("Nombre: " +nombre);
    console.log("Correo electronico: "+correo);
    console.log("Numero de cuenta: "+numcuenta);
    console.log("Tipo de cuenta: "+cuenta);
    console.log("Banco: "+banco);
    console.log("Monto de transferencia: "+valor);

}