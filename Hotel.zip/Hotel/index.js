function Cotizar(){
 let numpersonas = parseInt(document.getElementById ("numeropersonas").value)
 let numdias = parseInt(document.getElementById ("numerodias").value)
 let vrlpersona = 80000
 let descuento = 0
 let total = 0

 if (numpersonas > 6) {
   descuento = vrlpersona * 0.25
} 
 total = numpersonas * vrlpersona * numdias - descuento
 document.getElementById("total").innerHTML = total
} 
