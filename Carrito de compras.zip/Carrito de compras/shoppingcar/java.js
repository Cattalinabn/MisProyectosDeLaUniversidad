const header = document.querySelector("#header");
const contenedor = document.querySelector("#contenedor");
const body = document.querySelector("#body");
window.addEventListener("scroll", function() {
    if(contenedor.getBoundingClientRect ().top<10){
        header.classList.add("scroll")
    }
    else{
        header.classList.remove("scroll")
    }
})

/*function Cotizar(){
    let ValorMoto = parseInt(document.getElementById ("valormoto").value)
    let Cantidad = parseInt(document.getElementById ("cantidad").value)
   
    
   if (ValorMoto > 2) {
     Cantidad = ValorMoto * 2
   } 
    total = ValorMoto * Cantidad 
    document.getElementById("total").innerHTML = total
   } */


   function Cotizar(producto){
    let vlrProducto
  
    switch(producto){

        case "producto1": vlrProducto = 1200000000


    }

    document.getElementById("ValorMoto") = vlrProducto


   }
   