// Obtener la fecha de hoy
var today = new Date().toLocaleDateString();
document.getElementById("date").value = today;

// Contador para asignar un ID único a cada tarea
var taskId = 0;

// Función para agregar una tarea
function addTask() {
  var taskContainer = document.getElementById("taskContainer");

  var task = document.createElement("div");
  task.className = "task";
  task.id = "task-" + taskId;

  var taskInput = document.createElement("input");
  taskInput.type = "text";
  taskInput.name = "task";
  taskInput.placeholder = "Ingrese una tarea";

  var removeButton = document.createElement("input");
  removeButton.type = "button";
  removeButton.value = "Quitar";
  removeButton.onclick = function() {
    removeTaskById(task.id);
  };

  task.appendChild(taskInput);
  task.appendChild(removeButton);
  taskContainer.appendChild(task);

  taskId++;
}

// Función para quitar una tarea por su ID
function removeTaskById(taskId) {
  var task = document.getElementById(taskId);
  task.parentNode.removeChild(task);
}

// Función para quitar la última tarea agregada
function removeTask() {
  var taskContainer = document.getElementById("taskContainer");
  var tasks = taskContainer.getElementsByClassName("task");

  if (tasks.length > 0) {
    var lastTask = tasks[tasks.length - 1];
    taskContainer.removeChild(lastTask);
  }
}

// Función para reiniciar las tareas
function resetTasks() {
  var taskContainer = document.getElementById("taskContainer");
  taskContainer.innerHTML = "";
}
